# This UI current only has add staff and view all staff features.

# Instructions to run this front end v0.1:

open command line, cd into this project directory.
run npm install, then run npm start.